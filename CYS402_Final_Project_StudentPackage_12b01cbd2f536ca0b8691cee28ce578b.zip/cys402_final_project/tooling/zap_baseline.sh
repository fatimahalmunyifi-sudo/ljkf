#!/usr/bin/env bash
# OWASP ZAP baseline scan against a locally running PSU-ClinicLab instance.
# Prereq: app running at $TARGET (default http://127.0.0.1:5000) and Docker.
# Only scan an app you own / run locally.
set -euo pipefail
TARGET="${1:-http://127.0.0.1:5000}"
docker run --rm -t --network=host \
  ghcr.io/zaproxy/zaproxy:stable \
  zap-baseline.py -t "$TARGET" -r zap-report.html || true
echo "Report written to zap-report.html"
