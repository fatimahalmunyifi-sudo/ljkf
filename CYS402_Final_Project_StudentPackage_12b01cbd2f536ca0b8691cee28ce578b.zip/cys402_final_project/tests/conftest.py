"""Shared test setup for the CYS402 final project.

Loads the app in the psu_cliniclab/ folder and gives every test a fresh,
seeded database and a Flask test client. Set APP_DIR to point at a different
app folder if you keep your fixed code elsewhere.
"""
import importlib.util
import os
import sys
import tempfile
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_DIR = os.environ.get("APP_DIR", "psu_cliniclab")


def _load():
    folder = os.path.join(ROOT, APP_DIR)
    os.environ["PSUCLINIC_DB"] = os.path.join(tempfile.gettempdir(),
                                              "psuclinic_project_test.db")
    sys.path.insert(0, folder)
    seed_spec = importlib.util.spec_from_file_location(
        "proj_seed", os.path.join(folder, "seed.py"))
    seed = importlib.util.module_from_spec(seed_spec)
    seed_spec.loader.exec_module(seed)
    app_spec = importlib.util.spec_from_file_location(
        "proj_app", os.path.join(folder, "app.py"))
    app = importlib.util.module_from_spec(app_spec)
    app_spec.loader.exec_module(app)
    seed.seed(app.DB_PATH)
    sys.path.remove(folder)
    app.app.config.update(TESTING=True)
    return app


@pytest.fixture
def client():
    return _load().app.test_client()


@pytest.fixture
def module():
    return _load()
