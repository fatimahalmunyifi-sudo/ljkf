"""
OPTIONAL bonus tests. Passing these earns the hardening bonus described in the
brief. They cover password hashing, account lockout, and security headers.
Run:  pytest tests/test_bonus.py -v
"""


def test_passwords_not_plaintext(module):
    import sqlite3
    con = sqlite3.connect(module.DB_PATH)
    pw = con.execute("SELECT password FROM users LIMIT 1").fetchone()[0]
    con.close()
    assert pw != "alicepass"


def test_account_lockout(client):
    for _ in range(6):
        client.post("/login", data={"email": "bob@clinic.test",
                                    "password": "wrong"})
    r = client.post("/login",
                    data={"email": "bob@clinic.test", "password": "bobpass"},
                    follow_redirects=True)
    assert b"lock" in r.data.lower()


def test_security_headers_present(client):
    r = client.get("/")
    assert r.headers.get("Content-Security-Policy")
    assert r.headers.get("X-Content-Type-Options") == "nosniff"
    assert r.headers.get("X-Frame-Options") == "DENY"
