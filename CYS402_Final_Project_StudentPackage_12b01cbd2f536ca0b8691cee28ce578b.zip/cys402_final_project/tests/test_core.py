"""
REQUIRED tests. These define the three flaws you must fix to pass the project.
Run:  pytest tests/test_core.py -v
All four must pass.
"""


# 1 - SQL injection must not bypass login
def test_login_injection_is_blocked(client):
    r = client.post("/login",
                    data={"email": "' OR '1'='1' -- ", "password": "x"},
                    follow_redirects=True)
    assert b"Dashboard" not in r.data


# 2 - stored input must be shown as text, not run as a script
def test_stored_input_is_escaped(client):
    client.post("/login", data={"email": "alice@clinic.test",
                                "password": "alicepass"})
    client.post("/book", data={"date": "2026-10-01",
                               "reason": "<script>alert('x')</script>"})
    r = client.get("/dashboard")
    assert b"<script>alert('x')</script>" not in r.data
    assert b"&lt;script&gt;" in r.data


# 3 - a patient must not reach the admin page
def test_admin_forbidden_for_patient(client):
    client.post("/login", data={"email": "alice@clinic.test",
                                "password": "alicepass"})
    r = client.get("/admin")
    assert r.status_code == 403


# 4 - an admin still can (the feature must keep working)
def test_admin_allowed_for_admin(client):
    client.post("/login", data={"email": "admin@clinic.test",
                                "password": "admin123"})
    r = client.get("/admin")
    assert b"Admin console" in r.data
