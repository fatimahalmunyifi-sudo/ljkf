"""
PSU-ClinicLab (VULNERABLE build) - CYS402 Secure Software Development
================================================================
A deliberately insecure clinic-appointment web app used as the training
target for Labs 4-7. DO NOT deploy this build. Run it only on your own
machine, on localhost, for coursework.

Known planted weaknesses (students discover and fix these):
  - SQL injection in login and appointment search (string-built queries)
  - Stored XSS in appointment "reason" notes (unescaped rendering)
  - Passwords stored in plaintext
  - No brute-force protection on login
  - Hardcoded secret key
  - Broken access control on /admin (no role check)
  - No security response headers

The SECURE build (../app_secure/app.py) fixes every item above.
"""
from flask import Flask, request, redirect, url_for, session, render_template, g
import sqlite3
import os

DB_PATH = os.environ.get(
    "PSUCLINIC_DB", os.path.join(os.path.dirname(__file__), "psuclinic_vuln.db")
)

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
)
app.secret_key = "hardcoded-dev-secret-123"  # WEAKNESS: hardcoded secret


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


@app.route("/")
def index():
    return render_template("index.html", user=session.get("user"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        email = request.form.get("email", "")
        password = request.form.get("password", "")
        # WEAKNESS: SQL injection - user input concatenated into the query,
        # and plaintext password comparison.
        query = (
            "SELECT * FROM users WHERE email = '%s' AND password = '%s'"
            % (email, password)
        )
        row = get_db().execute(query).fetchone()
        if row:
            session["user"] = row["email"]
            session["role"] = row["role"]
            return redirect(url_for("dashboard"))
        error = "Invalid credentials."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    rows = get_db().execute(
        "SELECT * FROM appointments WHERE patient_email = '%s'"
        % session["user"]
    ).fetchall()
    return render_template("dashboard.html", user=session["user"], appts=rows)


@app.route("/search")
def search():
    term = request.args.get("q", "")
    results = []
    if term:
        # WEAKNESS: SQL injection in the search filter.
        query = (
            "SELECT * FROM appointments WHERE reason LIKE '%%%s%%'" % term
        )
        results = get_db().execute(query).fetchall()
    return render_template("search.html", term=term, results=results)


@app.route("/book", methods=["GET", "POST"])
def book():
    if "user" not in session:
        return redirect(url_for("login"))
    if request.method == "POST":
        reason = request.form.get("reason", "")
        date = request.form.get("date", "")
        # WEAKNESS: stored XSS - 'reason' is saved raw and later rendered
        # without escaping in the template.
        get_db().execute(
            "INSERT INTO appointments (patient_email, date, reason) "
            "VALUES (?, ?, ?)",
            (session["user"], date, reason),
        )
        get_db().commit()
        return redirect(url_for("dashboard"))
    return render_template("book.html")


@app.route("/admin")
def admin():
    # WEAKNESS: broken access control - only checks logged in, not role.
    if "user" not in session:
        return redirect(url_for("login"))
    users = get_db().execute("SELECT email, role FROM users").fetchall()
    appts = get_db().execute("SELECT * FROM appointments").fetchall()
    return render_template("admin.html", users=users, appts=appts)


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        from seed import seed
        seed(DB_PATH)
    # debug=True in production is itself a weakness (verbose errors).
    app.run(host="127.0.0.1", port=5000, debug=True)
