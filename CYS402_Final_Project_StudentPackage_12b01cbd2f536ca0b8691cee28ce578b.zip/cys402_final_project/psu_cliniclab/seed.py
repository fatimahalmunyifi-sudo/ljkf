"""Seed the PSU-ClinicLab database with sample users and appointments."""
import sqlite3
import os

SAMPLE_USERS = [
    ("alice@clinic.test", "alicepass", "patient"),
    ("bob@clinic.test", "bobpass", "patient"),
    ("admin@clinic.test", "admin123", "admin"),
]

SAMPLE_APPTS = [
    ("alice@clinic.test", "2026-09-01", "Annual check-up"),
    ("alice@clinic.test", "2026-09-15", "Blood test follow-up"),
    ("bob@clinic.test", "2026-09-03", "Physiotherapy"),
    ("admin@clinic.test", "2026-08-20", "Staff medical (confidential)"),
]


def seed(db_path):
    if os.path.exists(db_path):
        os.remove(db_path)
    con = sqlite3.connect(db_path)
    con.executescript(
        """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'patient'
        );
        CREATE TABLE appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_email TEXT NOT NULL,
            date TEXT NOT NULL,
            reason TEXT
        );
        """
    )
    con.executemany(
        "INSERT INTO users (email, password, role) VALUES (?, ?, ?)",
        SAMPLE_USERS,
    )
    con.executemany(
        "INSERT INTO appointments (patient_email, date, reason) "
        "VALUES (?, ?, ?)",
        SAMPLE_APPTS,
    )
    con.commit()
    con.close()
    print("Seeded", db_path)


if __name__ == "__main__":
    seed(os.path.join(os.path.dirname(__file__), "psuclinic_vuln.db"))
