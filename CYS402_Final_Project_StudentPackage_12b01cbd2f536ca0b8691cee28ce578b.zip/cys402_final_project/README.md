# CYS402 Final Project — Secure PSU-ClinicLab

PSU-ClinicLab is a small practice web app built for this course. It is not a
real service and is not on the internet. It runs only on your own computer,
and it is insecure on purpose. Your job is to break it, fix it, prove your
fixes with tests, and present your work.

This project is worth 25% of the course. It is deliberately focused: you fix
three core flaws, solve three short labs, and give a final presentation.

> Do not confuse this app with any website of a similar name. Attack only this
> app on your own machine, or the PortSwigger labs on your own account.

## What is in this folder
- `psu_cliniclab/` — the app you will harden. It runs, and it is insecure.
- `tests/test_core.py` — four required tests. You must make these pass.
- `tests/test_bonus.py` — three optional tests for the hardening bonus.
- `tooling/` — a static-analysis ruleset and a scan script.
- `data/` — sample data and practice attack payloads.
- `docs/` — install, user, and testing guides.
- `PROJECT_BRIEF.docx` — the full brief.
- `presentation_template.pptx` — a slide template for your final talk.

## Set up
You need Python 3.10 or newer.

```
pip install -r requirements.txt
cd psu_cliniclab
python app.py        # open http://127.0.0.1:5000
```

Logins: `alice@clinic.test / alicepass` (patient) and
`admin@clinic.test / admin123` (admin).

## Run the tests
From the project root:

```
pytest tests/test_core.py -v     # required
pytest tests/test_bonus.py -v     # optional bonus
```

Three of the four core tests fail at the start. Each failure marks a flaw you
must remove.

## What to do
1. Attack. Show three flaws in the running app: a login bypass by SQL
   injection, a stored script in an appointment note, and patient access to
   the admin page. Keep a screenshot of each.
2. Fix. Edit the app until the four core tests pass. Use parameterized
   queries, escape output, and check the admin role.
3. Present. Give a short talk that walks through each flaw, your fix, and the
   test that proves it, with a live demo.

Bonus: pass the three tests in `test_bonus.py` by hashing passwords, adding a
login lockout, and setting security headers.

## What to submit
- Your fixed source code.
- Screenshots of each attack working, then failing after your fix.
- The passing `pytest tests/test_core.py` output.
- Three PortSwigger "solved" banners (see the brief for which labs).
- Your final presentation (PowerPoint), built from the template.

## Rules
Attack only this app on your own machine, or the PortSwigger labs on your own
account. Never test these methods on any system you do not own. You may discuss
ideas, but the code and the slides must be your own.
