# Testing Guide — PSU-ClinicLab

## What the tests prove
`tests/test_security.py` fires the same attacks at both builds. Each attack
**succeeds** against `app_vulnerable` and is **blocked** by `app_secure`.
A remediation is "done" when a failing security test turns green.

## Run everything
```bash
pytest -v
```

## Coverage
| Test | Vulnerable | Secure |
|------|-----------|--------|
| SQLi login bypass | logs in | rejected |
| Stored XSS in notes | script survives | escaped |
| `/admin` access control | open to patients | 403 for patients, 200 for admin |
| Password storage | (n/a) | hashed, never plaintext |
| Brute-force lockout | (n/a) | locks after 5 fails |
| Security headers | absent | present |

## Add your own test (Lab 5 exercise)
When you find a new issue, write a test that fails on the vulnerable build,
fix the code, and watch it pass. Example skeleton:
```python
def test_my_finding_blocked_secure(secure):
    r = secure.get("/some/path?param=<payload>")
    assert b"<payload>" not in r.data
```

## Static & dynamic analysis (Lab 5)
```bash
# SAST
semgrep --config tooling/semgrep-security.yml app_vulnerable/
# DAST (app must be running at the target URL; Docker required)
bash tooling/zap_baseline.sh http://127.0.0.1:5000
```
