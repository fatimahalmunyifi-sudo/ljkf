# User Guide — PSU-ClinicLab

PSU-ClinicLab is a minimal clinic-appointment app used for coursework.

## Accounts (seeded)
| Email | Password | Role |
|-------|----------|------|
| alice@clinic.test | alicepass | patient |
| bob@clinic.test | bobpass | patient |
| admin@clinic.test | admin123 | admin |

## Pages
- **Home** — landing page.
- **Login** — sign in. In the secure build, five wrong tries lock the
  account for 15 minutes.
- **Dashboard** — your own appointments.
- **Book** — create an appointment (date `YYYY-MM-DD` + reason).
- **Search** — filter your appointments by text in the reason.
- **Admin** — staff-only in the secure build; lists all users and
  appointments. (In the vulnerable build any logged-in user can open it —
  that is the planted access-control flaw.)

## Typical flow
1. Log in as `alice`.
2. Book an appointment.
3. See it on the dashboard; search for a word in its reason.
4. Log in as `admin` to view the whole clinic.

## Security note
The vulnerable build accepts malicious input on purpose. Use it only for the
labs, on your own machine.
