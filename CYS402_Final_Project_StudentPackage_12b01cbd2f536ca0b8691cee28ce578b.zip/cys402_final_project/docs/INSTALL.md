# Installation Guide — PSU-ClinicLab Lab Codebase

## Requirements
- Python 3.10 or newer
- pip
- (Optional) Docker, for the OWASP ZAP DAST scan in Lab 5

## 1. Get the code
Unzip the repository and open a terminal in its root folder
(`cys402_labs_repo/`).

## 2. Create a virtual environment (recommended)
```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows
.venv\Scripts\activate
```

## 3. Install dependencies
```bash
pip install -r requirements.txt
```

## 4. Run a build
The database is seeded automatically on first launch.
```bash
# Vulnerable build (Labs 3–5 target)
cd app_vulnerable
python app.py                 # serves http://127.0.0.1:5000

# Secure build (reference solution) — in a second terminal
cd app_secure
export PSUCLINIC_SECRET="a-long-random-string"   # Windows: set PSUCLINIC_SECRET=...
python app.py                 # serves http://127.0.0.1:5001
```

## 5. Verify the install
```bash
pytest -v
```
Expect 11 passing tests.

## Troubleshooting
- **`ModuleNotFoundError: flask`** — the virtual environment is not active,
  or dependencies were not installed. Re-run steps 2–3.
- **`Address already in use`** — another process holds the port. Stop it, or
  change the port in the `app.run(...)` line.
- **`Operation not permitted` on the `.db` file** — set a writable DB path:
  `export PSUCLINIC_DB=/tmp/psuclinic.db` before launching.
- **Templates not found** — run `python app.py` from inside the build folder,
  or launch via the module as shown above.
